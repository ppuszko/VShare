from collections.abc import Iterator
from pathlib import Path
import shutil
import os

import pdfplumber
from odf.opendocument import load
from odf.text import P
from docx import Document
from fastapi import UploadFile
from uuid6 import uuid7

from src.api.documents.schemas import DocumentAdd
from src.core.config.file import FileConfig


class FileManager:
    def __init__(self, save_path: str = FileConfig.STORAGE_PATH):
        self._save_path = Path(save_path)
        self._extractors = {
            "pdf": self._extract_pdf,
            "odt": self._extract_odt,
            "docx": self._extract_docx
        }
        self._allowed_extensions = set(self._extractors.keys())

        
    def save_file(self, file: UploadFile, group_uid: str) -> str | None:
        filename = file.filename

        if filename is None:
            return None       
        if not Path(self._save_path / group_uid).is_dir():
            os.mkdir(Path(self._save_path / group_uid))
        
        extension = Path(filename).suffix.lstrip(".")
        if extension in self._allowed_extensions:
            file_name = str(uuid7()) + f".{extension}"
            dest = self._save_path / group_uid / file_name

            with dest.open("wb") as out:
                shutil.copyfileobj(file.file, out)
                return str(dest)
    

    def extract_text_from_files(self, files: list[DocumentAdd]) -> Iterator[tuple[str | None, DocumentAdd]]:
        for file in files:
            if file.storage_path is not None:
                extension = Path(file.storage_path).suffix.lstrip(".")
                extractor = self._extractors.get(extension)
                if extractor is not None:
                    yield extractor(file.storage_path), file
            else:
                yield None, file


    def _extract_pdf(self, file_path: str | Path) -> str:
        path = Path(file_path) 
        if not path.exists():
            raise FileNotFoundError(path)

        content = []
        with pdfplumber.open(path) as pdf:
            for page in pdf.pages:
                text = page.extract_text() 
                if text:
                    content.append(text)   
        
        return " ".join(content)


    def _extract_docx(self, file_path: str) -> str:
        path = Path(file_path) 
        if not path.exists():
            raise FileNotFoundError(path)
        
        doc = Document(file_path)
        
        paragraphs = [p.text.strip() for p in doc.paragraphs if p.text.strip()]
        
        return " ".join(paragraphs)



    def _extract_odt(self, file_path: str | Path) -> str:
        path = Path(file_path) 
        if not path.exists():
            raise FileNotFoundError(path)
        
        doc = load(path)

        content = []
        for p in doc.getElementsByType(P):
            text = "".join(node.data for node in p.childNodes if node.nodeType == 3).strip()
            if text:
                content.append(text)

        return " ".join(content)


def get_file_man() -> FileManager:
    return FileManager()


